import 'package:flutter/material.dart';
import 'package:tmap_ui_sdk_example/app.dart';

void main() {
  runApp(const TmapExampleApp());
}
